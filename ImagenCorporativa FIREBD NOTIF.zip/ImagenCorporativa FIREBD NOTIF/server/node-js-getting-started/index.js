var express = require('express');
var app = express();
app.set('port', (process.env.PORT || 5000));

// codifica los parametros e las ursl
var bodyParser = require("body-parser");
app.use(bodyParser.json()); // soporte para codificar json
app.use(bodyParser.urlencoded({extended: true})); //soporte decodificar extraer datos url

// conexion para "firebase"
var firebase = require("firebase");
// archivo creado en la configuracion y añadido al proyecto
// url que aparece en "database" de firebase sin diagonal al final
firebase.initializeApp({
  databaseURL: "https://petagram2-80262.firebaseio.com",
  serviceAccount: "Petagram2-4dd8b5ee5bcb.json"
});



app.use(express.static(__dirname + '/public'));

// views is directory for all template files
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');

app.get('/android', function(request, response) {
  response.render('pages/index');
});

//AGREGADA
//POST
//https://warm-river-38549.herokuapp.com/android
//token
var tokenDevicesURI = "token-device"; 
app.post("/" + tokenDevicesURI, function(request, response)
{
	var token = request.body.token;
	var user_instagram = request.body.user_instagram;		// nuevo campo guardar

	// traer la base de datos
	var db = firebase.database();

	// obetner la referencia de la base de datos
	// push asignara identificadores a cada registro
	// por ejemplo a un registro creo: -KT6lfRvB_WcH-Akg1ef
	var tokenDevices = db.ref(tokenDevicesURI).push();

	// estructura JSON
	// asi estara definida las tablas de la BD
	//???????????????????????????????????????
	// AQUI SE PUEDEN AGREGAR MAS CAMPOS 
	//???????????????????????????????????????
	// nuevo campo a guardar
	tokenDevices.set({  
		token: token,		
		user_instagram: user_instagram			
	});

	// regresa: https://petagram2-80262.firebaseio.com/token-device/-KT6lfRvB_WcH-Akg1ef"
	var path = tokenDevices.toString();

	// divide en un arreglo
	// 0 - https://petagram2-80262.firebaseio.com/token-device/
	// 1 - -KT6lfRvB_WcH-Akg1ef
	var pathSplit = path.split(tokenDevicesURI + "/");
	// toma el identificador creado con el push
	var idAutoGenerado = pathSplit[1];

	// genera un bjeto JSON
	var respuesta  = generarRespuestaAToken(db, idAutoGenerado);

	// añade un Header
	// indica de que tipo sera la respuesta
	response.setHeader("Content-Type", "application/json");

	//apartir de request recibe el token
	// request.body.nombre_usuario etc.
	// lo convierte en un formato String con forma de JSON
	response.send(JSON.stringify(respuesta));

});


function generarRespuestaAToken(db, idAutoGenerado )
{
	var respuesta = {};
	var usuario = "";
	var ref = db.ref("token-device");

	// obtiene el ultimo registro insertado
	ref.on("child_added", function(snapshot, prevChildKey){

		// obtiene el dato que se acaba de insertar
		usuario = snapshot.val();

		// nuevo campo a guardar
		respuesta = {

			id: idAutoGenerado,
			token: usuario.token,
			user_instagram: usuario.user_instagram		
		}
	});

	return respuesta;
}


app.listen(app.get('port'), function() {
  console.log('Node app is running on port', app.get('port'));
});


