package com.example.gezuzm.imagencorporativa.restAPIFIREBASE;

import com.example.gezuzm.imagencorporativa.restAPIFIREBASE.model.UsuarioResponse;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

/**
 * Created by mauricio on 02/10/16.
 */

public interface IEndPointsFIREBASE {



    // con el objeto respuesta
    // con una parametro
    // asi viene del servidor codificada en la URL
    @FormUrlEncoded
    @POST(ConstantesResApiFIREBASE.KEY_POST_ID_TOKEN)
    Call<UsuarioResponse> registrarTokenID(@Field("token") String token);


    // con el objeto respuesta
    // con una parametro
    // asi viene del servidor codificada en la URL
    @FormUrlEncoded
    @POST(ConstantesResApiFIREBASE.KEY_POST_ID_TOKEN)
    Call<UsuarioResponse> registrar_usuario(@Field("token") String id_dispositivo,
                                           @Field("user_instagram") String id_usuario_instagram);



    // con el objeto respuesta
    // con una parametro
    // asi viene del servidor codificada en la URL
    @FormUrlEncoded
    @POST(ConstantesResApiFIREBASE.KEY_POST_ID_TOKEN)
    Call<UsuarioResponse> registrar_id_foto(@Field("token") String id_dispositivo,
                                            @Field("user_instagram") String id_usuario_instagram,
                                            @Field("id_foto") String id_media);



    @GET(ConstantesResApiFIREBASE.KEY_TOQUE_MASCOTA)
    Call<UsuarioResponse> toqueMascota(@Path("id") String id, @Path("user_instagram") String id_usuario_instagram);


}
