package com.example.gezuzm.imagencorporativa.presentador;



import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.widget.Toast;


import com.example.gezuzm.imagencorporativa.VariableGlobal;
import com.example.gezuzm.imagencorporativa.db.ConstructorMascotas;
import com.example.gezuzm.imagencorporativa.fragment.IRecyclerViewFragmentView;
import com.example.gezuzm.imagencorporativa.pojo.Mascota;
import com.example.gezuzm.imagencorporativa.restApi.ConstantesRestApi;
import com.example.gezuzm.imagencorporativa.restApi.IEndpointsApi;
import com.example.gezuzm.imagencorporativa.restApi.adapter.RestApiAdapter;
import com.example.gezuzm.imagencorporativa.restApi.model.MascotaResponse;
import com.google.gson.Gson;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.R.attr.id;

/**
 * Created by mauricio on 04/09/16.
 */
public class RecyclerViewFragmentPresenter implements IRecyclerViewFragmentPresenter {

    private IRecyclerViewFragmentView iRecyclerViewFragmentView;
    private Context context;

    private ConstructorMascotas constructorMascotas;
    private ArrayList<Mascota> mascotas;

    private String id;

    public RecyclerViewFragmentPresenter()
    {


    }

    public RecyclerViewFragmentPresenter(IRecyclerViewFragmentView iRecyclerViewFragmentView, Context context) {

        this.iRecyclerViewFragmentView = iRecyclerViewFragmentView;
        this.context = context;

        //obtenerMascotasBaseDatos();

        String usuario;

        VariableGlobal g = VariableGlobal.getInstance();

        if (g.getPrimeraVez() )
        {
            usuario = "pascalitodog";
        }
        else
        {
            SharedPreferences sharedPreferences = context.getSharedPreferences("MisPreferencias",Context.MODE_PRIVATE);
            usuario = sharedPreferences.getString("usuario", "pascalitodog");
        }


        if (!usuario.contains("pascalitodog")) {

            id = obtenerIdUsuario(usuario);

            if (id != null)
            {
                Toast.makeText(context, "usuario: " + usuario, Toast.LENGTH_LONG).show();

                obtenerMediaUser(id);
            }
            else
            {

                Toast.makeText(context, "Usuario : " + usuario + " no válido", Toast.LENGTH_LONG).show();
            }
        }
        else
        {
            Toast.makeText(context, "Usuario: " + usuario, Toast.LENGTH_LONG).show();

            obtenerMediosRecientes();
        }
    }

    @Override
    public void obtenerMascotasBaseDatos() {

        constructorMascotas = new ConstructorMascotas(context);

        mascotas = constructorMascotas.ObtenerDatos();

        mostrarMascotasRV();
    }

    // DE instagram
    @Override
    public void obtenerMediosRecientes() {
        //1.- generar el ADAPTADOR con el api de instagram
        RestApiAdapter restApiAdapter = new RestApiAdapter();
        Gson gsonMediaRecent = restApiAdapter.construyeGsonDeserializadorMediaRecent();

        // 2.- Ubicamos en el archivo que contiene los ENDPOINTS
       IEndpointsApi iEndpointsApi =  restApiAdapter.establecerConexionRestApiInstagram(gsonMediaRecent);

        //3.- se almacena en una coleccion de calls
       Call<MascotaResponse>  mascotaResponseCall = iEndpointsApi.getRecentMedia();

        //4.- son los eventos que si falla o es saisfactoria
        mascotaResponseCall.enqueue(new Callback<MascotaResponse>() {
            @Override
            public void onResponse(Call<MascotaResponse> call, Response<MascotaResponse> response) {

                // la repsuesta se almacena en el objeto JSON
                MascotaResponse mascotaResponse = response.body();

                mascotas =  mascotaResponse.getMascotas();

               // id = mascotas.get(0).getId();

                mostrarMascotasRV();
            }

            @Override
            public void onFailure(Call<MascotaResponse> call, Throwable t) {
                Toast.makeText(context, "Algo Paso", Toast.LENGTH_LONG).show();

                Log.e("Fallo la coneccion", t.toString());
            }
        });

    }


    @Override
    public String obtenerIdUsuario(String usuario )
    {
        // permitir la llamada sea SINCRONA
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        //1.- generar el ADAPTADOR con el api de instagram
        RestApiAdapter restApiAdapter = new RestApiAdapter();
        Gson gsonID = restApiAdapter.construyeGsonDeserializadorID();

        // 2.- Ubicamos en el archivo que contiene los ENDPOINTS
        IEndpointsApi iEndpointsApi =  restApiAdapter.establecerConexionRestApiInstagram(gsonID);

        //3.- se almacena en una coleccion de calls
        Call<MascotaResponse>  mascotaResponseCall = iEndpointsApi.getId(usuario, ConstantesRestApi.ACCESS_TOKEN);
      //    Call<MascotaResponse>  mascotaResponseCall = iEndpointsApi.getId2();

        try{

            Response<MascotaResponse> response = mascotaResponseCall.execute();

            // la repsuesta se almacena en el objeto JSON
            MascotaResponse mascotaResponse = response.body();

            mascotas =  mascotaResponse.getMascotas();

            id = mascotas.get(0).getId();

        }
        catch (Exception ex)
        {
            Toast.makeText(context, ex.toString(),Toast.LENGTH_LONG);

        }

        return id;
    }

    @Override
    public void obtenerMediaUser(String id) {

        if (id != null && id.contains("")) {
            //1.- generar el ADAPTADOR con el api de instagram
            RestApiAdapter restApiAdapter = new RestApiAdapter();
            Gson gsonID = restApiAdapter.construyeGsonDeserializadorMediaUser();

            // 2.- Ubicamos en el archivo que contiene los ENDPOINTS
            IEndpointsApi iEndpointsApi = restApiAdapter.establecerConexionRestApiInstagram(gsonID);

            //3.- se almacena en una coleccion de calls
            Call<MascotaResponse> mascotaResponseCall = iEndpointsApi.getMediaUser(id, ConstantesRestApi.ACCESS_TOKEN);
            //    Call<MascotaResponse>  mascotaResponseCall = iEndpointsApi.getId2();

            //4.- son los eventos que si falla o es saisfactoria
            mascotaResponseCall.enqueue(new Callback<MascotaResponse>() {
                @Override
                public void onResponse(Call<MascotaResponse> call, Response<MascotaResponse> response) {

                    // la repsuesta se almacena en el objeto JSON
                    MascotaResponse mascotaResponse = response.body();

                    mascotas = mascotaResponse.getMascotas();

                    mostrarMascotasRV();

                }

                @Override
                public void onFailure(Call<MascotaResponse> call, Throwable t) {
                    Toast.makeText(context, "Algo Paso", Toast.LENGTH_LONG).show();

                    Log.e("Fallo la coneccion", t.toString());
                }
            });

        }
    }


    @Override
    public void mostrarMascotasRV() {

        iRecyclerViewFragmentView.inicializarAdaptadorRV(iRecyclerViewFragmentView.crearAdaptador(mascotas));

        //iRecyclerViewFragmentView.generarLinearLayoutVertical();
        iRecyclerViewFragmentView.generarGridLayout();
    }

    @Override
    public String cargarUsuario() {

        String usuario = "";

            try{

                FileInputStream fis = context.openFileInput("usuario.txt");
                InputStreamReader isr = new InputStreamReader(fis);

                char[] inputBuffer = new char[100];

                int charRead;
                while((charRead = isr.read(inputBuffer)) > 0){
                    // Convertimos los char a String
                    String readString = String.copyValueOf(inputBuffer, 0, charRead);
                    usuario += readString;

                    inputBuffer = new char[100];
                }

                // Establecemos en el EditText el texto que hemos leido
                if (usuario.contains("gezuzm") )
                {
                    usuario= "pascalitodog";
                }

                // Mostramos un Toast con el proceso completado
                Toast.makeText(context, "Usuario: " + usuario, Toast.LENGTH_SHORT).show();

                isr.close();
            }catch (IOException ex){
                usuario= "";
                ex.printStackTrace();
            }

        return usuario;
    }

    @Override
    public String buscarIDUsuario() {
        return null;
    }


}
