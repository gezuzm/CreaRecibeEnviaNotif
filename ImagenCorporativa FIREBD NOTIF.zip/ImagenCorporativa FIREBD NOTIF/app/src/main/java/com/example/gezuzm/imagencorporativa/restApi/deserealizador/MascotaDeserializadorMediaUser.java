package com.example.gezuzm.imagencorporativa.restApi.deserealizador;

import com.example.gezuzm.imagencorporativa.pojo.Mascota;
import com.example.gezuzm.imagencorporativa.restApi.JsonKeys;
import com.example.gezuzm.imagencorporativa.restApi.model.MascotaResponse;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;

import java.lang.reflect.Type;
import java.util.ArrayList;

/**
 * Created by mauricio on 01/10/16.
 */

public class MascotaDeserializadorMediaUser implements JsonDeserializer<MascotaResponse> {


    @Override
    public MascotaResponse deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        Gson gson  = new Gson();
        // trae todos los datos del JSON
        MascotaResponse mascotaResponse = gson.fromJson(json, MascotaResponse.class);

        JsonArray mascotaResponseData = json.getAsJsonObject().getAsJsonArray(JsonKeys.MEDIA_RESPONSE_ARRAY);

        mascotaResponse.setMascotas(deserializarMascotaJsonMediaUser(mascotaResponseData));
        return mascotaResponse;
    }

    private ArrayList<Mascota> deserializarMascotaJsonMediaUser(JsonArray mascotaResponseData)
    {
        ArrayList<Mascota> mascotas = new ArrayList<>();

        for (int i= 0; i < mascotaResponseData.size(); i++)
        {
            JsonObject mascotaResponseDataObject  = mascotaResponseData.get(i).getAsJsonObject();
            JsonObject userJson = mascotaResponseDataObject.getAsJsonObject(JsonKeys.USER);

            String id = userJson.get(JsonKeys.USER_ID).getAsString();
            String nombreCompleto = userJson.get(JsonKeys.USER_FULLNAME).getAsString();

            JsonObject imageJson        = mascotaResponseDataObject.getAsJsonObject(JsonKeys.MEDIA_IMAGES);

            String id_media =  mascotaResponseDataObject.get(JsonKeys.MEDIA_ID).getAsString();

            JsonObject stdResolutionJson = imageJson.getAsJsonObject(JsonKeys.MEDIA_STANDARD_RESOLUTION);

            String urlFoto              = stdResolutionJson.get(JsonKeys.MEDIA_URL).getAsString();

            JsonObject likesJson = mascotaResponseDataObject.getAsJsonObject(JsonKeys.MEDIA_LIKES);
            int likes = likesJson.get(JsonKeys.MEDIA_LIKES_COUNT).getAsInt();

            Mascota mascotaActual = new Mascota();
            mascotaActual.setId(id);
            mascotaActual.setNombreCompleto(nombreCompleto);
            mascotaActual.setUrlImgMascota(urlFoto);
            mascotaActual.setNoLike(likes);

            mascotaActual.setId_media(id_media);

            mascotas.add(mascotaActual);

        }

        return mascotas;
    }


}
