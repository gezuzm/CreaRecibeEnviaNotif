package com.example.gezuzm.imagencorporativa.restAPIFIREBASE;

/**
 * Created by mauricio on 02/10/16.
 */

public final class ConstantesResApiFIREBASE {

    public static final String ROOT_URL = "https://warm-river-38549.herokuapp.com/";
    public static final String KEY_POST_ID_TOKEN = "token-device/";

    public static final String KEY_TOQUE_MASCOTA = "toque-mascota/{id}/{user_instagram}/";



}
