package com.example.gezuzm.imagencorporativa.restApi;

import com.example.gezuzm.imagencorporativa.ArchivoDatos;

/**
 * Created by mauricio on 19/09/16.
 */
public class ConstantesRestApi {

    //https://api.instagram.com/v1/
    public static final String VERSION = "/v1/";
    public static final String ROOT_URL = "https://api.instagram.com" + VERSION;
    public static final String ACCESS_TOKEN = "3946703253.e33f096.6193f5ab9bd94fea8bf3aac43e8c594a";
    public static final String KEY_ACCESS_TOKEN = "?access_token=";
    public static final String KEY_GET_RECENT_MEDIA_USER = "users/self/media/recent/";
    public static final String URL_GET_RECENT_MEDIA_USER =  KEY_GET_RECENT_MEDIA_USER + KEY_ACCESS_TOKEN +  ACCESS_TOKEN;


    // users/search?q=jack&access_token=ACCESS-TOKEN
    public static final String KEY_GET_SEARCH_ID_USER = "users/search";
    public static final String KEY_ID_SERACH_ID = "?q=";
    public static final String ACCESS_TOKEN_SEARCH_ID = "&access_token=";
    public static final String URL_SEARCH_ID_USER =  KEY_GET_SEARCH_ID_USER + KEY_ID_SERACH_ID + ACCESS_TOKEN_SEARCH_ID;


    public static final String URL_SEARCH_ID_USER2 =  KEY_GET_SEARCH_ID_USER + KEY_ID_SERACH_ID + "pascalitodog" +
                                                      ACCESS_TOKEN_SEARCH_ID + ACCESS_TOKEN;



    // users/{user-id}/media/recent/?access_token=ACCESS-TOKEN
    public static final String KEY_GET_ID_MEDIA_USER = "users/{user-id}/media/recent/";
    public static final String ACCESS_TOKEN_MEDIA_USER = "?access_token=";
    public static final String URL_GET_MEDIA_USER =  KEY_GET_ID_MEDIA_USER  + ACCESS_TOKEN_MEDIA_USER;


    //https://api.instagram.com/v1/media/{media-id}/likes?access_token=ACCESS-TOKEN
    public static final String KEY_MEDIA_ID_FOTO = "media/{media-id}/likes";
    public static final String ACCESS_TOKEN_MEDIA_ID_FOTO = "?access_token=";
    public static final String URL_POST_MEDIA_ID_FOTO =  KEY_MEDIA_ID_FOTO  + ACCESS_TOKEN_MEDIA_ID_FOTO;



}
