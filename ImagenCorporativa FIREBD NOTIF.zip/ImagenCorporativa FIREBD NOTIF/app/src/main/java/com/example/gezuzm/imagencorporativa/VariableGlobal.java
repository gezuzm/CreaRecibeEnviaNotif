package com.example.gezuzm.imagencorporativa;

import android.app.Application;

/**
 * Created by mauricio on 02/10/16.
 */

public class VariableGlobal  {

        private static VariableGlobal instance;
        private static Boolean primeraVez = true;

        private VariableGlobal()
        {}

        public Boolean getPrimeraVez() {
            return VariableGlobal.primeraVez;
        }

        public void setPrimeraVezValue(Boolean val) {
            VariableGlobal.primeraVez = val;
        }


        public static synchronized VariableGlobal getInstance()
        {
            if (instance == null)
            {
                instance = new VariableGlobal();
            }

            return instance;
        }
}
