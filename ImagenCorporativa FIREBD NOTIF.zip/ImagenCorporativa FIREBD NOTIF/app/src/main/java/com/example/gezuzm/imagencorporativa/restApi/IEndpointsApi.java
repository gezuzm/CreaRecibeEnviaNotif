package com.example.gezuzm.imagencorporativa.restApi;


import com.example.gezuzm.imagencorporativa.ArchivoDatos;
import com.example.gezuzm.imagencorporativa.restApi.model.MascotaResponse;

import retrofit2.Call;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;


/**
 * Created by mauricio on 19/09/16.
 */
public interface IEndpointsApi {

    //                                         @GET --> CONSULTA
    // ConstantesRestApi.URL_GET_RECENT_MEDIA_USER  --> URL de consulta
    //
    @GET(ConstantesRestApi.URL_GET_RECENT_MEDIA_USER)
    Call<MascotaResponse> getRecentMedia();


    // @QUERY  -->    La anotación @Query indica el parámetro que se le pasará a la ruta
    //                y la variable que le sigue, indica el parámetro del método
    //@PATH    -->    que acepta un parámetro, en este caso el usuario, que se le pasa cuando
    //                se realiza la llamada al método
    //@GET("/users/{user}/repos")   -->     @Path("user") String user
    //
    // busca un "USUARIO" para encontrar su "ID"
    @GET(ConstantesRestApi.URL_SEARCH_ID_USER)
    Call<MascotaResponse> getId(@Query("q") String name,
                                @Query("access_token") String accesToken);

/*
    @GET(ConstantesRestApi.URL_SEARCH_ID_USER2)
    Call<MascotaResponse> getId2();
*/

    // busca los "DATOS" del usuario a partir de "ID"
    @GET(ConstantesRestApi.URL_GET_MEDIA_USER)
    Call<MascotaResponse> getMediaUser(@Path("user-id") String userId,
                                       @Query("access_token") String accesToken);



    // da un LIKE a un foto
  //  @FormUrlEncoded
    @POST(ConstantesRestApi.URL_POST_MEDIA_ID_FOTO)
    Call<MascotaResponse>  postMediaLike(@Path("media-id") String mediaID,
                                         @Query("access_token") String accesToken);

}
