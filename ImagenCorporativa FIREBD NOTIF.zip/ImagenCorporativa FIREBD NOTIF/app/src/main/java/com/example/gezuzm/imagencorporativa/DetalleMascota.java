package com.example.gezuzm.imagencorporativa;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.gezuzm.imagencorporativa.restAPIFIREBASE.IEndPointsFIREBASE;
import com.example.gezuzm.imagencorporativa.restAPIFIREBASE.adapter.RestAPIFIREBASEAdapter;
import com.example.gezuzm.imagencorporativa.restAPIFIREBASE.model.UsuarioResponse;
import com.google.firebase.iid.FirebaseInstanceId;
import com.squareup.picasso.Picasso;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by mauricio on 19/09/16.
 */
public class DetalleMascota extends AppCompatActivity {

        private static final String KEY_EXTRA_URL = "url";
        private static final String KEY_EXTRA_LIKES = "like";
        //private TextView tvNombre;
        //private TextView tvTelefono;
        //private TextView tvEmail;
        private ImageView imgMascotaDetalle;
        private TextView tvNoLikeDetalle;

         VariableGlobal g;
        String id="";

        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_detalle_mascota_foto);

            Bundle extras = getIntent().getExtras();
            String url   = extras.getString(KEY_EXTRA_URL);
            int likes    = extras.getInt(KEY_EXTRA_LIKES);
           String id_media = extras.getString("id_media");

          //  String id = extras.getString("id");
            String id_usuario_instagram = extras.getString("id_usuario_instagram");

            tvNoLikeDetalle     = (TextView) findViewById(R.id.tvNoLikeDetalle);
            tvNoLikeDetalle.setText(String.valueOf(likes));

            imgMascotaDetalle = (ImageView) findViewById(R.id.imgMascotaDetalle);


            Picasso.with(this)
                    .load(url)
                    .placeholder(R.drawable.el_escarador)
                    .into(imgMascotaDetalle);

            enviarIDFoto(id_media);

            toqueMascota( id,  id_usuario_instagram);
        }



    public void enviarIDFoto(String id_media)
    {

        g = VariableGlobal.getInstance();

        String usuario = "";

        if (g.getPrimeraVez() )
        {
            usuario = "pascalitodog";
        }
        else
        {
            SharedPreferences sharedPreferences = getBaseContext().getSharedPreferences("MisPreferencias", Context.MODE_PRIVATE);
            usuario = sharedPreferences.getString("usuario", "pascalitodog");
        }


        String id_dispositivo = FirebaseInstanceId.getInstance().getToken();
        String id_usuario_instagram = usuario;   //solamente para mi usuario

        enviarIDFotoBD(id_dispositivo, id_usuario_instagram, id_media);

        // Log.d("TOKEN", token);

    }

    private void enviarIDFotoBD(String id_dispositivo, String id_usuario_instagram, String id_media)
    {
        // permitir la llamada sea SINCRONA
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        RestAPIFIREBASEAdapter restAPIFIREBASEAdapter = new RestAPIFIREBASEAdapter();
        IEndPointsFIREBASE iEndPointsFIREBASE = restAPIFIREBASEAdapter.establecerConexionRestAPI();

        Call<UsuarioResponse> usuarioResponseCall = iEndPointsFIREBASE.registrar_id_foto(id_dispositivo, id_usuario_instagram, id_media);

        try {
            Response<UsuarioResponse> response = usuarioResponseCall.execute();

            UsuarioResponse usuarioResponse = response.body();

            id = usuarioResponse.getId();
            Toast.makeText(getBaseContext(), "Insertado en BD correctamente...", Toast.LENGTH_LONG ).show();

            // esto se puede guardar en sharedpreference
           // Log.d("ID_FIREBASE", usuarioResponse.getId());
           // Log.d("ID_DISPOSITIVO", usuarioResponse.getToken());
           // Log.d("ID_USUARIO_INSTAGRAM", usuarioResponse.getUser_instagram());
           // Log.d("ID_MEDIA", usuarioResponse.getId_media());

        }
        catch (Exception ex)
        {
            Toast.makeText(getBaseContext(), ex.toString(),Toast.LENGTH_LONG).show();

        }

        /*
        usuarioResponseCall.enqueue(new Callback<UsuarioResponse>() {
            @Override
            public void onResponse(Call<UsuarioResponse> call, Response<UsuarioResponse> response) {

                // la clase es identica a la respuesta
                UsuarioResponse usuarioResponse = response.body();

                if (g.getPrimeraVez())
                {
                    Toast.makeText(activity.getBaseContext(),  "USUARIO DEFAULT....Datos leidos del servidor: id_dispsitivo: " +
                            usuarioResponse.getToken().toString() + ", id_usuario_instagram: " +
                            usuarioResponse.getUser_instagram().toString() + ", id_foto: " +
                            usuarioResponse.getId_media(), Toast.LENGTH_LONG ).show();

                }
                else
                {
                    Toast.makeText(activity.getBaseContext(),  "Datos leidos del servidor: id_dispsitivo: " +
                            usuarioResponse.getToken().toString() + ", id_usuario_instagram: " +
                            usuarioResponse.getUser_instagram().toString() + ", id_foto: " +
                            usuarioResponse.getId_media(), Toast.LENGTH_LONG ).show();
                }
                // esto se puede guardar en sharedpreference
                Log.d("ID_FIREBASE", usuarioResponse.getId());
                Log.d("ID_DISPOSITIVO", usuarioResponse.getToken());
                Log.d("ID_USUARIO_INSTAGRAM", usuarioResponse.getUser_instagram());
                Log.d("ID_MEDIA", usuarioResponse.getId_media());

            }

            @Override
            public void onFailure(Call<UsuarioResponse> call, Throwable t) {

            }
        });*/

    }


    public void toqueMascota(String id, String id_usuario_instagram){

        Log.d("TOQUE MASCOTA", "true");

        // permitir la llamada sea SINCRONA
        //StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        //StrictMode.setThreadPolicy(policy);
        //UsuarioResponse usuarioResponse = new UsuarioResponse("fOxoYkOXhQg:APA91bFCA3_5H5z91JGuc9cpuFZGgHcAIMKvIDya47bl6HZp_T","pacalitodog");

        RestAPIFIREBASEAdapter restAPIFIREBASEAdapter = new RestAPIFIREBASEAdapter();
        IEndPointsFIREBASE iEndPointsFIREBASE = restAPIFIREBASEAdapter.establecerConexionRestAPI();

        Call<UsuarioResponse> usuarioResponseCall = iEndPointsFIREBASE.toqueMascota(id, id_usuario_instagram);

        usuarioResponseCall.enqueue(new Callback<UsuarioResponse>() {
            @Override
            public void onResponse(Call<UsuarioResponse> call, Response<UsuarioResponse> response) {

                // la clase es identica a la respuesta
                UsuarioResponse usuarioResponse = response.body();

                Toast.makeText(getBaseContext(),  "Envio Notificacion a: " +
                                usuarioResponse.getUser_instagram()
                                , Toast.LENGTH_LONG ).show();

              /*  if (g.getPrimeraVez())
                {
                    Toast.makeText(activity.getBaseContext(),  "USUARIO DEFAULT....Datos leidos del servidor: id_dispsitivo: " +
                            usuarioResponse.getToken().toString() + ", id_usuario_instagram: " +
                            usuarioResponse.getUser_instagram().toString() + ", id_foto: " +
                            usuarioResponse.getId_media(), Toast.LENGTH_LONG ).show();

                }
                else
                {
                    Toast.makeText(activity.getBaseContext(),  "Datos leidos del servidor: id_dispsitivo: " +
                            usuarioResponse.getToken().toString() + ", id_usuario_instagram: " +
                            usuarioResponse.getUser_instagram().toString() + ", id_foto: " +
                            usuarioResponse.getId_media(), Toast.LENGTH_LONG ).show();
                }
                // esto se puede guardar en sharedpreference
                Log.d("ID_FIREBASE", usuarioResponse.getId());
                Log.d("ID_DISPOSITIVO", usuarioResponse.getToken());
                Log.d("ID_USUARIO_INSTAGRAM", usuarioResponse.getUser_instagram());
                Log.d("ID_MEDIA", usuarioResponse.getId_media());
                */
                Log.d("ALGO","BIEN");
            }

            @Override
            public void onFailure(Call<UsuarioResponse> call, Throwable t) {
                Log.d("ALGO","PASO");
            }
        });

        /*
        try {
            Response<UsuarioResponse> response = usuarioResponseCall.execute();

            UsuarioResponse usuarioResponse = response.body();

           // usuarioResponse.getId();
           // usuarioResponse.getToken();
           // usuarioResponse.getUser_instagram();

            //Toast.makeText(getBaseContext(), "Insertado en BD correctamente...", Toast.LENGTH_LONG ).show();

            // esto se puede guardar en sharedpreference
            // Log.d("ID_FIREBASE", usuarioResponse.getId());
            // Log.d("ID_DISPOSITIVO", usuarioResponse.getToken());
            // Log.d("ID_USUARIO_INSTAGRAM", usuarioResponse.getUser_instagram());
            // Log.d("ID_MEDIA", usuarioResponse.getId_media());

        }
        catch (Exception ex)
        {
            Toast.makeText(getBaseContext(), ex.toString(),Toast.LENGTH_LONG).show();

        }
        */


    }


}
