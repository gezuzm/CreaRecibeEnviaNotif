package com.example.gezuzm.imagencorporativa;

import android.util.Log;

import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.FirebaseInstanceIdService;

/**
 * Created by mauricio on 02/10/16.
 */

public class NotificationIDTokenService extends FirebaseInstanceIdService {

    public static final String TAG = "FIREBASE TOKEN";

    @Override
    public void onTokenRefresh() {
        //
       // Log.d(TAG, "Solicitando token");
        String token = FirebaseInstanceId.getInstance().getToken();
        //Log.d(TAG, "Solicitando token: " + token);

        // If you want to send messages to this application instance or
        // manage this apps subscriptions on the server side, send the
        // Instance ID token to your app server.

     //  enviarTokenRegistro(token);
    }

    private void enviarTokenRegistro(String token)
    {
        Log.d(TAG, token);

    }
}
