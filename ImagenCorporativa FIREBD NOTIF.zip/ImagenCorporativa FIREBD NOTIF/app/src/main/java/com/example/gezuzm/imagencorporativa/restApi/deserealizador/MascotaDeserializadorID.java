package com.example.gezuzm.imagencorporativa.restApi.deserealizador;

import com.example.gezuzm.imagencorporativa.pojo.Mascota;
import com.example.gezuzm.imagencorporativa.restApi.JsonKeys;
import com.example.gezuzm.imagencorporativa.restApi.model.MascotaResponse;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;

import java.lang.reflect.Type;
import java.util.ArrayList;

/**
 * Created by mauricio on 01/10/16.
 */

public class MascotaDeserializadorID implements JsonDeserializer<MascotaResponse> {


    @Override
    public MascotaResponse deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        Gson gson  = new Gson();
        // trae todos los datos del JSON
        MascotaResponse mascotaResponse = gson.fromJson(json, MascotaResponse.class);

        JsonArray mascotaResponseData = json.getAsJsonObject().getAsJsonArray(JsonKeys.MEDIA_RESPONSE_ARRAY);

        mascotaResponse.setMascotas(deserializarMascotaJson_ID(mascotaResponseData));
        return mascotaResponse;
    }


    // METODO QUE OBTIENE EL ID
    private ArrayList<Mascota> deserializarMascotaJson_ID(JsonArray mascotaResponseData)
    {
        ArrayList<Mascota> mascotas = new ArrayList<>();

            JsonObject mascotaResponseDataObject  = mascotaResponseData.get(0).getAsJsonObject();
            String id = mascotaResponseData.get(0).getAsJsonObject().get(JsonKeys.USER_ID).getAsString();

            Mascota mascotaActual = new Mascota();
            mascotaActual.setId(id);

            mascotas.add(mascotaActual);

        return mascotas;
    }

}
