package com.example.gezuzm.imagencorporativa.restAPIFIREBASE.adapter;

import com.example.gezuzm.imagencorporativa.restAPIFIREBASE.ConstantesResApiFIREBASE;
import com.example.gezuzm.imagencorporativa.restAPIFIREBASE.IEndPointsFIREBASE;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by mauricio on 02/10/16.
 */

public class RestAPIFIREBASEAdapter {

    public IEndPointsFIREBASE establecerConexionRestAPI()
    {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(ConstantesResApiFIREBASE.ROOT_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                ;

        return  retrofit.create(IEndPointsFIREBASE.class);

    }
}
